#error "PINS_DEBUGGING is not yet supported for STM32!"
